-- DropIndex
DROP INDEX `images_user_key` ON `images`;
