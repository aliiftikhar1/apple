-- AlterTable
ALTER TABLE `customer` MODIFY `List_degree_completed` VARCHAR(191) NULL;
