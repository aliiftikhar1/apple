-- AlterTable
ALTER TABLE `customer` ADD COLUMN `file` VARCHAR(191) NULL;
