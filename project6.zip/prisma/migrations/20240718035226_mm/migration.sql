-- AlterTable
ALTER TABLE `adminuser` ADD COLUMN `imgurl` VARCHAR(191) NULL;
