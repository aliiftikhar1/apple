-- AlterTable
ALTER TABLE `customer` ADD COLUMN `imgurl` VARCHAR(191) NULL;
