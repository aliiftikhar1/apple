-- AlterTable
ALTER TABLE `customer` ADD COLUMN `status` VARCHAR(191) NULL;
