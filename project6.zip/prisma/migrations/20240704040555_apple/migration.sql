-- AlterTable
ALTER TABLE `customer` ADD COLUMN `Visa_Country` VARCHAR(191) NULL,
    ADD COLUMN `Visa_Type` VARCHAR(191) NULL;
