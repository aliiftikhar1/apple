-- AlterTable
ALTER TABLE `customer` ADD COLUMN `SelectedFileType` VARCHAR(191) NULL;
